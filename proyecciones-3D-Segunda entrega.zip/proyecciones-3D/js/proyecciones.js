/* proyecciones.js
   Clase que gestiona los controles de ángulos para proyecciones (isométrica,
   dimétrica y trimétrica). Sincroniza inputs numéricos, fija valores
   según el modo seleccionado, valida que la suma sea 360º y emite un evento
   'angulosActualizados' cuando cambian los ángulos para que otros módulos
   (ej. main.js) actualicen la cámara.
*/
class ClaseProyeccionesEditable {
    constructor() {
        // Modo actual: 'isometrica' | 'dimetrica' | 'trimetrica'
        this.modo = 'isometrica';

        // Referencias a elementos del DOM (inputs numéricos)
        this.inputX = document.getElementById('inputX');
        this.inputY = document.getElementById('inputY');
        this.inputZ = document.getElementById('inputZ');

        // Botones para seleccionar modo y elemento para mostrar advertencias
        this.btnIso = document.getElementById('btnIsometrica');
        this.btnDi = document.getElementById('btnDimetrica');
        this.btnTri = document.getElementById('btnTrimetrica');
        this.advertencia = document.getElementById('advertencia');
        this.advertenciaRestricciones = document.getElementById('advertenciaRestricciones');

        // Vincular eventos y establecer estado inicial (isométrica)
        this._vincular();
        this._establecerIsometrica();
    }

    // Vincula handlers a botones e inputs.
    _vincular() {
        this.btnIso.addEventListener('click', () => this._establecerIsometrica());
        this.btnDi.addEventListener('click', () => this._establecerDimetrica());
        this.btnTri.addEventListener('click', () => this._establecerTrimetrica());

        // Cuando el usuario escribe en los inputs numéricos, se procesa el cambio
        this.inputX.addEventListener('input', () => this._onInputChange('X'));
        this.inputY.addEventListener('input', () => this._onInputChange('Y'));
        this.inputZ.addEventListener('input', () => this._onInputChange('Z'));
        
        // Validar restricciones al perder el foco
        this.inputX.addEventListener('blur', () => this._validarRestricciones('X'));
        this.inputY.addEventListener('blur', () => this._validarRestricciones('Y'));
    }

    // Actualiza el aspecto de los botones (marca el activo)
    _activarBoton(b) {
        [this.btnIso, this.btnDi, this.btnTri].forEach(x => {
            x.classList.remove('active');
            x.classList.remove('primario');
        });
        b.classList.add('active');
        b.classList.add('primario');
    }

    // Establece el modo isométrico: valores fijos (120º cada uno) y no editables.
    _establecerIsometrica() {
        this.modo = 'isometrica';
        this._activarBoton(this.btnIso);
        this._setValues(120, 120, 120);
        this._setEditable(false, false, false);
        this.advertenciaRestricciones.style.display = 'none';
    }

    // Establece el modo dimétrico: ejemplo de valores iniciales y sólo X editable.
    // Comportamiento: Y se copia desde X, Z se calcula para que la suma sea 360º.
    _establecerDimetrica() {
        this.modo = 'dimetrica';
        this._activarBoton(this.btnDi);
        // Establecer valores iniciales que no sean 120
        this._setValues(130, 130, 100);
        // X editable, Y y Z no
        this._setEditable(true, false, false);
        this.advertenciaRestricciones.style.display = 'none';
    }

    // Establece el modo trimétrico: X y Y editables, Z calculado para completar 360º.
    _establecerTrimetrica() {
        this.modo = 'trimetrica';
        this._activarBoton(this.btnTri);
        // Establecer valores iniciales diferentes
        this._setValues(130, 110, 120);
        // X y Y editables, Z no
        this._setEditable(true, true, false);
        this.advertenciaRestricciones.style.display = 'none';
    }

    // Pone valores en los tres controles (inputs) y valida la suma.
    _setValues(x, y, z) {
        this.inputX.value = x.toFixed(2);
        this.inputY.value = y.toFixed(2);
        this.inputZ.value = z.toFixed(2);
        this._validarSuma();
    }

    // Activa/desactiva edición en inputs (true = editable).
    _setEditable(x, y, z) {
        this.inputX.disabled = !x;
        this.inputY.disabled = !y;
        this.inputZ.disabled = !z;
    }

    // Maneja cambios de inputs. 'cual' indica cuál cambió ('X'|'Y'|'Z').
    // Según el modo aplica reglas: en dimétrica X controla Y y Z, en trimétrica X/Y controlan Z.
    // Después valida la suma y emite evento 'angulosActualizados'.
    _onInputChange(cual) {
        let x = parseFloat(this.inputX.value) || 0;
        let y = parseFloat(this.inputY.value) || 0;
        let z = parseFloat(this.inputZ.value) || 0;

        // En isométrica siempre forzamos 120,120,120 ignore entrada del usuario
        if (this.modo === 'isometrica') { this._setValues(120, 120, 120); return; }

        // Validar restricciones específicas del modo
        if (this.modo === 'dimetrica') {
            if (cual === 'X') {
                // Validar que X no sea 120 en dimétrica
                if (x === 120) {
                    this.advertenciaRestricciones.textContent = "En proyección dimétrica, el ángulo X no puede ser 120°";
                    this.advertenciaRestricciones.style.display = 'block';
                    this.inputX.value = 130;
                    x = 130;
                } else {
                    this.advertenciaRestricciones.style.display = 'none';
                }
                
                x = this._clamp(x);
                this.inputX.value = x.toFixed(2);
                // En dimétrica definimos Y = X
                this.inputY.value = x.toFixed(2);
                // Z se calcula para que x + y + z = 360
                const nz = 360 - (x + x);
                // Si el cálculo resulta en un valor negativo, mostrar advertencia
                if (nz < 0) {
                    this.advertenciaRestricciones.textContent = "Los ángulos no pueden generar valores negativos. Ajuste el valor de X.";
                    this.advertenciaRestricciones.style.display = 'block';
                    return; // No emitir evento de actualización
                }
                this.inputZ.value = nz.toFixed(2);
            }
        } else if (this.modo === 'trimetrica') {
            // X y Y editables; recalcular Z para completar 360
            if (cual === 'X' || cual === 'Y') {
                x = this._clamp(x);
                y = this._clamp(y);
                
                // Validar que X e Y no sean iguales en trimétrica
                if (x === y) {
                    this.advertenciaRestricciones.textContent = "En proyección trimétrica, los ángulos X e Y no pueden ser iguales";
                    this.advertenciaRestricciones.style.display = 'block';
                    
                    // Ajustar automáticamente Y si es igual a X
                    if (cual === 'Y') {
                        y = (x + 10) > 360 ? x - 10 : x + 10;
                        this.inputY.value = y.toFixed(2);
                    } else {
                        // Si se está modificando X, ajustar Y
                        y = (x + 10) > 360 ? x - 10 : x + 10;
                        this.inputY.value = y.toFixed(2);
                    }
                } else {
                    this.advertenciaRestricciones.style.display = 'none';
                }
                
                this.inputX.value = x.toFixed(2);
                this.inputY.value = y.toFixed(2);
                const nz = 360 - (x + y);
                // Si el cálculo resulta en un valor negativo, mostrar advertencia
                if (nz < 0) {
                    this.advertenciaRestricciones.textContent = "La suma de X e Y no puede exceder 360°. Ajuste los valores.";
                    this.advertenciaRestricciones.style.display = 'block';
                    return; // No emitir evento de actualización
                }
                this.inputZ.value = nz.toFixed(2);
            }
        }

        // Mostrar u ocultar advertencia si la suma no es ~360
        if (!this._validarSuma()) {
            return; // No emitir evento si la validación falla
        }

        // Solo emitir evento si no hay advertencias de restricciones activas
        if (this.advertenciaRestricciones.style.display === 'none') {
            window.dispatchEvent(new CustomEvent('angulosActualizados', { 
                detail: { 
                    x: parseFloat(this.inputX.value), 
                    y: parseFloat(this.inputY.value), 
                    z: parseFloat(this.inputZ.value) 
                } 
            }));
        }
    }
    
    // Valida las restricciones específicas de cada modo al perder el foco
    _validarRestricciones(cual) {
        if (this.modo === 'dimetrica' && cual === 'X') {
            const valor = parseFloat(this.inputX.value);
            if (valor === 120) {
                this.advertenciaRestricciones.textContent = "En proyección dimétrica, el ángulo X no puede ser 120°";
                this.advertenciaRestricciones.style.display = 'block';
                this.inputX.value = 130;
                this._onInputChange('X');
            }
        } else if (this.modo === 'trimetrica' && (cual === 'X' || cual === 'Y')) {
            const x = parseFloat(this.inputX.value);
            const y = parseFloat(this.inputY.value);
            if (x === y) {
                this.advertenciaRestricciones.textContent = "En proyección trimétrica, los ángulos X e Y no pueden ser iguales";
                this.advertenciaRestricciones.style.display = 'block';
                this.inputY.value = (x + 10) > 360 ? x - 10 : x + 10;
                this._onInputChange('Y');
            }
        }
    }

    // Limita valores entre 0 y 360 y maneja NaN
    _clamp(v) { if (isNaN(v)) v = 0; if (v < 0) v = 0; if (v > 360) v = 360; return v; }

    // Valida que x+y+z sea aproximadamente 360; muestra advertencia si no.
    _validarSuma() {
        const x = parseFloat(this.inputX.value) || 0;
        const y = parseFloat(this.inputY.value) || 0;
        const z = parseFloat(this.inputZ.value) || 0;
        const suma = x + y + z;
        const tol = 0.05; // tolerancia en grados
        
        if (Math.abs(suma - 360) > tol) {
            this.advertencia.style.display = 'block';
            return false;
        } else {
            this.advertencia.style.display = 'none';
            return true;
        }
    }

    // Devuelve los ángulos actuales como números (útil para consumidores externos).
    obtenerAngulos() { 
        return { 
            x: parseFloat(this.inputX.value) || 0, 
            y: parseFloat(this.inputY.value) || 0, 
            z: parseFloat(this.inputZ.value) || 0 
        }; 
    }
}