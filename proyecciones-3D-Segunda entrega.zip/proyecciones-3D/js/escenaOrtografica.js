/* escenaOrtografica.js (ACTUALIZADO) */

/*
Clase para gestionar una escena ortográfica simple con cámara, luces,
ejes estilo GeoGebra y utilidades para mover la cámara usando matrices
de rotación y TWEEN para animaciones suaves.

Responsabilidades principales:
- Crear escena, cámara ortográfica y renderer.
- Añadir iluminación, ejes y una grilla de referencia.
- Calcular posiciones de cámara a partir de ángulos (uso de matrices 3x3).
- Animar la cámara hacia una orientación determinada o hacia una vista isométrica.
*/
class ClaseEscenaOrtografica {
    constructor(contenedor) {
        // contenedor: elemento DOM donde se inserta el canvas de Three.js
        this.contenedor = contenedor;
        this.escena = new THREE.Scene();
        // distancia radial inicial de la cámara respecto al origen (usa para cálculos)
        this.d = 6.0;

        // Crear cámara ortográfica: ajustar left/right según aspecto
        const aspect = contenedor.clientWidth / contenedor.clientHeight;
        const frust = 3.5; // semiancho del frustum ortográfico en eje y
        // left, right, top, bottom, near, far
        this.camara = new THREE.OrthographicCamera(-frust * aspect, frust * aspect, frust, -frust, -100, 100);
        // Posicionar la cámara a lo largo del eje z, apuntando al origen
        this.camara.position.set(0, 0, this.d);
        this.camara.up.set(0, 1, 0);
        this.camara.lookAt(0, 0, 0);

        // Renderer con antialias y fondo transparente (alpha)
        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        // Limitar pixel ratio para evitar sobreuso de GPU en pantallas de alta densidad
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
        // Fijar tamaño del renderer al tamaño del contenedor (no usa CSS)
        this.renderer.setSize(contenedor.clientWidth, contenedor.clientHeight, false);
        contenedor.appendChild(this.renderer.domElement);

        // Iluminación básica: luz ambiental y direccional
        this.escena.add(new THREE.AmbientLight(0xffffff, 0.8));
        const dir = new THREE.DirectionalLight(0xffffff, 0.6);
        dir.position.set(4, 6, 5);
        this.escena.add(dir);

        // Añadir ejes estilo GeoGebra (cilindros y conos que indican ejes X,Y,Z)
        this._crearEjesGeogebra();

        // GridHelper como referencia en plano; girado para verse como plano XY
        const grid = new THREE.GridHelper(20, 20, 0xeeeeee, 0xeeeeee);
        grid.rotation.x = Math.PI / 2;
        grid.material.transparent = true;
        grid.material.opacity = 0.75;
        this.escena.add(grid);

        // Escuchar redimensionado para actualizar proyección ortográfica
        window.addEventListener('resize', () => this._onResize());
    }

    // Actualiza frustum y tamaño del renderer cuando cambia el tamaño del contenedor.
    _onResize() {
        const w = this.contenedor.clientWidth;
        const h = this.contenedor.clientHeight;
        const aspect = w / h;
        const frust = 3.5;
        this.camara.left = -frust * aspect;
        this.camara.right = frust * aspect;
        this.camara.top = frust;
        this.camara.bottom = -frust;
        this.camara.updateProjectionMatrix();
        this.renderer.setSize(w, h, false);
    }

    // Renderiza la escena con la cámara actual
    render() { this.renderer.render(this.escena, this.camara); }

    // Construye cilindros y conos para representar los ejes X (rojo), Y (verde) y Z (azul)
    _crearEjesGeogebra() {
        const largo = 4.6;
        const grosor = 0.03;
        const matX = new THREE.MeshBasicMaterial({ color: 0xff3b30 });
        const matY = new THREE.MeshBasicMaterial({ color: 0x10b981 });
        const matZ = new THREE.MeshBasicMaterial({ color: 0x3b82f6 });
        const cilindroGeo = new THREE.CylinderGeometry(grosor, grosor, largo, 12);

        // Eje X: rotado para alinearse con el eje X y desplazado a la mitad del largo
        const ejeX = new THREE.Mesh(cilindroGeo, matX);
        ejeX.rotation.z = -Math.PI / 2;
        ejeX.position.x = largo / 2;
        this.escena.add(ejeX);

        // Eje Y: vertical
        const ejeY = new THREE.Mesh(cilindroGeo, matY);
        ejeY.position.y = largo / 2;
        this.escena.add(ejeY);

        // Eje Z: rotado para alinearse con Z
        const ejeZ = new THREE.Mesh(cilindroGeo, matZ);
        ejeZ.rotation.x = Math.PI / 2;
        ejeZ.position.z = largo / 2;
        this.escena.add(ejeZ);

        // Conos en los extremos para indicar la dirección positiva de cada eje
        const cono = new THREE.ConeGeometry(0.08, 0.3, 20);
        const fleX = new THREE.Mesh(cono, matX);
        fleX.rotation.z = -Math.PI / 2;
        fleX.position.set(largo + 0.12, 0, 0);
        this.escena.add(fleX);

        const fleY = new THREE.Mesh(cono, matY);
        fleY.position.set(0, largo + 0.12, 0);
        this.escena.add(fleY);

        const fleZ = new THREE.Mesh(cono, matZ);
        fleZ.rotation.x = Math.PI / 2;
        fleZ.position.set(0, 0, largo + 0.12);
        this.escena.add(fleZ);
    }

    // ====== ROTACIONES Y MATRICES ======
    // Utilidades para construir matrices de rotación 3x3 y aplicarlas a vectores.
    // Notas:
    // - Las matrices se representan como arrays de 9 elementos en orden fila-major.
    // - Los ángulos de entrada suelen darse en grados; _gradosARad convierte a radianes.

    _gradosARad(g) { return g * Math.PI / 180; }

    // Matriz de rotación alrededor del eje X por 'rad' radianes
    _matRx(rad) {
        const c = Math.cos(rad),
            s = Math.sin(rad);
        // [1 0 0; 0 c -s; 0 s c]
        return [1, 0, 0, 0, c, -s, 0, s, c];
    }

    // Matriz de rotación alrededor del eje Y por 'rad' radianes
    _matRy(rad) {
        const c = Math.cos(rad),
            s = Math.sin(rad);
        // [c 0 s; 0 1 0; -s 0 c]
        return [c, 0, s, 0, 1, 0, -s, 0, c];
    }

    // Matriz de rotación alrededor del eje Z por 'rad' radianes
    _matRz(rad) {
        const c = Math.cos(rad),
            s = Math.sin(rad);
        // [c -s 0; s c 0; 0 0 1]
        return [c, -s, 0, s, c, 0, 0, 0, 1];
    }

    // Multiplica dos matrices 3x3 A * B (ambas en fila-major).
    _multMat3(A, B) {
        const C = new Array(9).fill(0);
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                let s = 0;
                for (let k = 0; k < 3; k++) {
                    s += A[i * 3 + k] * B[k * 3 + j];
                }
                C[i * 3 + j] = s;
            }
        }
        return C;
    }

    // Aplica una matriz 3x3 a un vector {x,y,z}, devolviendo el vector transformado.
    _aplicarMat3(mat, v) {
        return {
            x: mat[0] * v.x + mat[1] * v.y + mat[2] * v.z,
            y: mat[3] * v.x + mat[4] * v.y + mat[5] * v.z,
            z: mat[6] * v.x + mat[7] * v.y + mat[8] * v.z
        };
    }

    // === NUEVO ORDEN DE ROTACIÓN (Ry -> Rx -> Rz) ===
    // Calcula la posición de la cámara en coordenadas cartesianas a partir de
    // tres ángulos (en grados). El orden de rotación aplicado al vector inicial
    // (0,0,d) es: rotación en Y, luego X, luego Z.
    // Pasos:
    // 1. Convertir grados a radianes.
    // 2. Construir matrices Rx, Ry, Rz.
    // 3. Calcular M = Ry * Rx * Rz (composición en ese orden).
    // 4. Aplicar M al vector inicial v0 = (0,0,d).
    calcularPosicionCamaraPorMatrices(xDeg, yDeg, zDeg) {
        const xr = this._gradosARad(xDeg),
            yr = this._gradosARad(yDeg),
            zr = this._gradosARad(zDeg);
        const Rx = this._matRx(xr),
            Ry = this._matRy(yr),
            Rz = this._matRz(zr);

        // Multiplicaciones: primero Ry * Rx, luego ese resultado * Rz
        const tmp = this._multMat3(Ry, Rx);
        const M = this._multMat3(tmp, Rz);

        // Vector inicial a rotar: cámara colocada en (0,0,d)
        const v0 = { x: 0, y: 0, z: this.d };
        return this._aplicarMat3(M, v0);
    }

    // Mueve la cámara interpolando su posición actual hacia la calculada por
    // 'calcularPosicionCamaraPorMatrices' usando TWEEN para animación suave.
    // Durante la animación se actualiza la posición y se mantiene la mirada al origen.
    moverCamaraConTween(xDeg, yDeg, zDeg, duracion = 700) {
        const objetivo = this.calcularPosicionCamaraPorMatrices(xDeg, yDeg, zDeg);
        const inicio = { x: this.camara.position.x, y: this.camara.position.y, z: this.camara.position.z };
        new TWEEN.Tween(inicio).to(objetivo, duracion).easing(TWEEN.Easing.Quadratic.InOut).onUpdate(() => {
            this.camara.position.set(inicio.x, inicio.y, inicio.z);
            this.camara.lookAt(0, 0, 0);
        }).start();
    }

    // ===== VISTA ISOMÉTRICA REAL =====
    // Mueve la cámara hacia una posición isométrica "real" donde las
    // coordenadas x,y,z tienen la misma proyección: posición (d/√3, d/√3, d/√3).
    // Se anima con TWEEN de forma similar a moverCamaraConTween.
    moverCamaraIsometrica(duracion = 700) {
        const d = this.d;
        const len = Math.sqrt(3);
        const objetivo = {
            x: d / len,
            y: d / len,
            z: d / len
        };

        const inicio = {
            x: this.camara.position.x,
            y: this.camara.position.y,
            z: this.camara.position.z
        };

        new TWEEN.Tween(inicio)
            .to(objetivo, duracion)
            .easing(TWEEN.Easing.Quadratic.InOut)
            .onUpdate(() => {
                this.camara.position.set(inicio.x, inicio.y, inicio.z);
                this.camara.lookAt(0, 0, 0);
            })
            .start();
    }
}