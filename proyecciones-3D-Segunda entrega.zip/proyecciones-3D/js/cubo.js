/* cubo.js (ACTUALIZADO) */

// Clase que encapsula un cubo, su armazón (aristas), la diagonal desde el origen
// y una "punta" esférica en el vértice opuesto. Proporciona métodos para cambiar
// el tamaño y rotar el conjunto.
class ClaseCubo {
    // escena: THREE.Scene donde se añadirá el grupo; lado: longitud del lado del cubo
    constructor(escena, lado = 1.6) {
        this.escena = escena;
        this.lado = lado;

        // Grupo que contiene todas las piezas del cubo (malla, aristas, línea, punta).
        // Usar un grupo permite transformar todo el conjunto de forma unificada.
        this.grupo = new THREE.Group();
        escena.add(this.grupo);

        // Crear la malla (cubo translúcido) y el vector (línea + esfera)
        this._crearCubo();
        this._crearVector();
    }

    _crearCubo() {
        // Geometría cúbica con tamaño 'lado'
        const geo = new THREE.BoxGeometry(this.lado, this.lado, this.lado);

        // Material translúcido para ver el interior y la arista por fuera
        const mat = new THREE.MeshStandardMaterial({
            color: 0x9ca3ff,
            transparent: true,
            opacity: 0.42,
            metalness: 0.02,
            roughness: 0.6,
            side: THREE.DoubleSide
        });

        // Malla del cubo. Se desplaza +lado/2 en cada eje para que el vértice
        // mínimo (0,0,0) quede en el origen del mundo — así la diagonal va desde
        // el origen hasta (lado, lado, lado).
        this.malla = new THREE.Mesh(geo, mat);
        this.malla.position.set(this.lado / 2, this.lado / 2, this.lado / 2);
        this.grupo.add(this.malla);

        // Aristas visibles del cubo (líneas) usando la misma geometría base.
        const edges = new THREE.EdgesGeometry(geo);
        const matL = new THREE.LineBasicMaterial({ color: 0x0b0b0b });
        this.aristas = new THREE.LineSegments(edges, matL);
        // La arista se posiciona igual que la malla para que coincidan.
        this.aristas.position.set(this.lado / 2, this.lado / 2, this.lado / 2);
        this.grupo.add(this.aristas);
    }

    _crearVector() {
        // Diagonal desde el origen (0,0,0) hasta el vértice opuesto (lado,lado,lado).
        // 'punto' es la posición final de la punta (esfera).
        const punto = new THREE.Vector3(this.lado, this.lado, this.lado);

        // Crear un BufferGeometry para una línea con dos vértices: inicio y fin.
        // El arreglo contiene [x0,y0,z0, x1,y1,z1].
        const pos = new Float32Array([0, 0, 0, punto.x, punto.y, punto.z]);
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));

        // Línea que representa la diagonal del cubo. 'linewidth' puede no tener
        // efecto en todos los sistemas pero se deja por claridad.
        this.linea = new THREE.Line(
            geo,
            new THREE.LineBasicMaterial({ color: 0xd946ef, linewidth: 2 })
        );

        // Esfera pequeña en la punta para marcar visualmente el vértice opuesto.
        const esf = new THREE.SphereGeometry(0.045, 12, 12);
        const matE = new THREE.MeshStandardMaterial({ color: 0xd946ef, metalness: 0.3, roughness: 0.6 });
        this.punta = new THREE.Mesh(esf, matE);
        this.punta.position.copy(punto);

        this.grupo.add(this.linea);
        this.grupo.add(this.punta);
    }

    // Cambia el tamaño del cubo a 'nuevo' y anima la punta de la diagonal hacia
    // el nuevo vértice final. Se reconstruye la malla y las aristas para la nueva
    // geometría.
    actualizarTamano(nuevo) {
        this.lado = nuevo;

        // Eliminar malla y aristas antiguas del grupo y liberar geometrías.
        this.grupo.remove(this.malla);
        this.grupo.remove(this.aristas);
        this.malla.geometry.dispose();
        this.aristas.geometry.dispose();

        // Recrear malla/aristas con el nuevo tamaño
        this._crearCubo();

        // Animar la posición final de la línea (los elementos 3,4,5 en el buffer)
        // desde el valor actual hasta (lado, lado, lado) usando TWEEN.
        const pos = this.linea.geometry.attributes.position.array;
        const inicio = { x: pos[3], y: pos[4], z: pos[5] };
        const destino = { x: this.lado, y: this.lado, z: this.lado };
        new TWEEN.Tween(inicio).to(destino, 700).easing(TWEEN.Easing.Quadratic.InOut).onUpdate(() => {
            // Actualizar el buffer de posición de la línea y la posición de la esfera
            pos[3] = inicio.x;
            pos[4] = inicio.y;
            pos[5] = inicio.z;
            this.linea.geometry.attributes.position.needsUpdate = true;
            this.punta.position.set(inicio.x, inicio.y, inicio.z);
        }).start();
    }

    // Ajusta la línea y la esfera instantáneamente al vértice (lado,lado,lado).
    fijarVector() {
        const pos = this.linea.geometry.attributes.position.array;
        pos[3] = this.lado;
        pos[4] = this.lado;
        pos[5] = this.lado;
        this.linea.geometry.attributes.position.needsUpdate = true;
        this.punta.position.set(this.lado, this.lado, this.lado);
    }

    // === NUEVO: rotar cubo alrededor del vector diagonal ===
    // Aplica una rotación al 'grupo' usando un quaternion generado a partir
    // del eje diagonal (1,1,1) normalizado y un ángulo en radianes.
    rotarAlrededorVector(anguloRad) {
        // Eje de la diagonal normalizado
        const eje = new THREE.Vector3(1, 1, 1).normalize();
        const q = new THREE.Quaternion();
        q.setFromAxisAngle(eje, anguloRad);

        // Establece la rotación del grupo a la del quaternion (sobrescribe rotaciones previas).
        this.grupo.setRotationFromQuaternion(q);
    }

    //NUEVO
    obtenerVectorDiagonal() {
        // El vector diagonal va desde el centro del cubo hasta el vértice seleccionado
        // En un cubo centrado en el origen, esto es simplemente la posición del vértice
        if (this.esferaPunta) {
            return this.esferaPunta.position.clone();
        }
        return new THREE.Vector3(1, 1, 1).normalize(); // Valor por defecto
    }
}