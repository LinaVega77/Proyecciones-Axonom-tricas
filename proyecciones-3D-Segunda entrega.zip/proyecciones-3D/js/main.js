/* main.js (CORREGIDO) */

// Variables globales que almacenan la escena ortográfica, el cubo y el gestor de proyecciones
let escena, cubo, proyecciones, vectorInfo;

// Inicializa la aplicación: crea escena, cubo, configura controles y arranca la animación
function init() {
    const cont = document.getElementById('area3d');

    // Crear la escena ortográfica (clase que maneja cámara, luces, ejes y renderer)
    escena = new ClaseEscenaOrtografica(cont);

    // Crear el cubo en la escena; tomar el tamaño inicial desde el input (o 1.6 por defecto)
    cubo = new ClaseCubo(escena.escena, parseFloat(document.getElementById('inputTamano').value) || 1.6);

    // Ajustar inmediatamente la línea/esfera al vértice actual del cubo
    cubo.fijarVector();

    // Crear el gestor de proyecciones (clase externa que proporciona ángulos para dimétrica/trimétrica)
    proyecciones = new ClaseProyeccionesEditable();

    // Vista inicial: mover cámara a la isométrica "real" con animación
    escena.moverCamaraIsometrica(700);

    // Escuchar evento personalizado 'angulosActualizados' para mover la cámara cuando cambien ángulos globales
    window.addEventListener('angulosActualizados', (ev) => {
        const d = ev.detail; // { x, y, z } en grados
        escena.moverCamaraConTween(d.x, d.y, d.z, 600); // animar a la nueva orientación
    });

    // Botones que fijan vistas: isométrica, dimétrica y trimétrica
    document.getElementById('btnIsometrica').addEventListener('click', () => {
        // Mueve cámara a isométrica real
        escena.moverCamaraIsometrica(700);
    });

    document.getElementById('btnDimetrica').addEventListener('click', () => {
        // Obtener ángulos desde el gestor y animar la cámara a esa orientación
        const ang = proyecciones.obtenerAngulos();
        escena.moverCamaraConTween(ang.x, ang.y, ang.z, 700);
    });

    document.getElementById('btnTrimetrica').addEventListener('click', () => {
        // Igual que dimétrica: usar los ángulos definidos para trimétrica
        const ang = proyecciones.obtenerAngulos();
        escena.moverCamaraConTween(ang.x, ang.y, ang.z, 700);
    });

    // Control para cambiar el tamaño del cubo en tiempo real
    document.getElementById('inputTamano').addEventListener('input', (e) => {
        const v = parseFloat(e.target.value) || 1;
        cubo.actualizarTamano(v); // reconstruye malla y anima la punta
        actualizarInfoVector(); // Actualizar vector cuando cambia el tamaño
    });

    // Crear elemento para mostrar información del vector
    vectorInfo = document.createElement('div');
    vectorInfo.id = 'vectorInfo';
    vectorInfo.style.marginTop = '8px';
    vectorInfo.style.fontSize = '14px';
    vectorInfo.style.color = '#e8eaed';
    vectorInfo.style.fontFamily = 'monospace';
    
    // Insertar después del control de rotación
    const rotacionContainer = document.querySelector('.controles:last-child');
    if (rotacionContainer) {
        rotacionContainer.appendChild(vectorInfo);
    }

    // Función para actualizar la información del vector
    function actualizarInfoVector() {
        if (cubo && cubo.obtenerVectorDiagonal && vectorInfo) {
            const vector = cubo.obtenerVectorDiagonal();
            vectorInfo.textContent = `Vector: (${vector.x.toFixed(2)}, ${vector.y.toFixed(2)}, ${vector.z.toFixed(2)})`;
        }
    }

    // Nuevo control: rotar el cubo alrededor de su diagonal (entrada en grados)
    document.getElementById('inputRotacionVector').addEventListener('input', (e) => {
        const grados = parseFloat(e.target.value) || 0;
        const rad = grados * Math.PI / 180;
        cubo.rotarAlrededorVector(rad); // aplica quaternion al grupo del cubo
        
        // Actualizar información del vector
        actualizarInfoVector();
    });

    // Inicializar información del vector
    actualizarInfoVector();

    // Arrancar bucle de animación
    animate();
}

// Bucle de animación: solicita frame, actualiza TWEEN y renderiza la escena
function animate() {
    requestAnimationFrame(animate);
    TWEEN.update(); // actualizar animaciones gestionadas por TWEEN.js
    if (escena && escena.render) {
        escena.render(); // renderizar con la cámara ortográfica actual
    }
}

// Inicializar cuando el DOM esté listo
window.addEventListener('DOMContentLoaded', init);